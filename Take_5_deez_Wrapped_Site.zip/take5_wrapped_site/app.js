(()=>{
'use strict';
const DB=window.TAKE5_DATA;
if(!DB){document.querySelector('#stage').textContent='Data unavailable: missing app-data.js';return;}
const N=DB.meta.members;
const colors={
 cover:{bg:'#d9ff6d',ink:'#2c155e',orb:'#ff79bb',blob:'#8d60f9',special:'#ff79bb'},
 stats:{bg:'#ffb5cb',ink:'#32104b',orb:'#fff087',blob:'#d988ef',special:'#f9e65a'},
 texts:{bg:'#b9f5e6',ink:'#24204f',orb:'#ffbc7e',blob:'#70ceee',special:'#f867ac'},
 laughs:{bg:'#c1b0ff',ink:'#261157',orb:'#d9fc70',blob:'#f7a3d7',special:'#f0fa69'},
 rate:{bg:'#fdde78',ink:'#2d1856',orb:'#ff8ba4',blob:'#91e9e2',special:'#f579a5'},
 volume:{bg:'#d7ff72',ink:'#26134a',orb:'#ff7fba',blob:'#99c8f4',special:'#ff7fba'},
 comedy:{bg:'#ff9ec5',ink:'#351156',orb:'#fff18f',blob:'#9d6ae6',special:'#e3f981'},
 chaos:{bg:'#abd7ff',ink:'#2a1349',orb:'#f7b3d0',blob:'#c7f18c',special:'#ec5c8e'},
 hall:{bg:'#f4aaea',ink:'#311557',orb:'#fff088',blob:'#a8e9d0',special:'#d8ff71'},
 spotlight:{bg:'#d7ff6f',ink:'#33164b',orb:'#ee81bd',blob:'#86d8ff',special:'#fa83bf'},
 history:{bg:'#adfff0',ink:'#252052',orb:'#e7b7f5',blob:'#ffbe92',special:'#f380ac'},
 champs:{bg:'#f5c6ff',ink:'#321258',orb:'#acfbdf',blob:'#f4d16c',special:'#d8ff71'},
 outro:{bg:'#f4ef84',ink:'#271254',orb:'#ff78ad',blob:'#8dcaf1',special:'#ff84a2'}
};
const slides=[
{id:'cover',group:'INTRO',label:'The opening act',kind:'cover',theme:'cover'},
{id:'numbers',group:'INTRO',label:'By the numbers',kind:'stats',theme:'stats'},
{id:'texts',group:'LEADERBOARDS',label:'The talking leaderboard',kind:'leader',metric:'messages',title:'WHO NEVER\nSTOPS TALKING?',unit:'texts sent',theme:'texts'},
{id:'laughs',group:'LEADERBOARDS',label:'The laugh leaderboard',kind:'leader',metric:'hahas_received',title:'THE LAUGHS\nDON’T LIE.',unit:'Haha reacts received',theme:'laughs'},
{id:'rate',group:'LEADERBOARDS',label:'The comedy leaderboard',kind:'leader',metric:'hahas_rate',title:'QUALITY OVER\nQUANTITY.',unit:'Haha reacts / 100 texts',theme:'rate'},
...['yapper','clown','comedian','triple','killer','resuscitator','night','hater','supplier','novelist'].map((a,i)=>({id:a,group:'THE AWARDS',label:['Certified Yapper','Class Clown','The Comedian','Triple Text Menace','Conversation Killer','The Resuscitator','Midnight Menace','Professional Hater','Content Supplier','The Novelist'][i],kind:'award',theme:['volume','comedy','chaos','volume','comedy','chaos','comedy','chaos','volume','comedy'][i],award:a,index:i})),
{id:'hall',group:'HALL OF FAME',label:'Top five messages',kind:'hall',theme:'hall'},
{id:'spotlight',group:'HALL OF FAME',label:'The funniest text',kind:'spotlight',theme:'spotlight'},
{id:'shift',group:'THE RECORD BOOK',label:'Year-over-year shifts',kind:'shift',theme:'history'},
{id:'champs',group:'THE RECORD BOOK',label:'Historical champions',kind:'champs',theme:'champs'},
{id:'outro',group:'FINALE',label:'The final roast',kind:'outro',theme:'outro'},
];
const state={period:'2026',index:0,private:false};
const el=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(num,dec=0)=>Number(num||0).toLocaleString('en-US',{minimumFractionDigits:dec,maximumFractionDigits:dec});
const yr=()=>DB.periods[state.period];
const c=()=>slides[state.index];
const award=id=>yr().awards.find(x=>x.id===id);
const value=(x,metric)=>fmt(x,metric==='hahas_rate'?2:metric==='avg_words'?1:0);
const themed=s=>{const t=colors[s.theme];return `style="--bg:${t.bg};--ink:${t.ink};--orb:${t.orb};--blob:${t.blob};--special:${t.special}"`};
const topLabel=()=>state.period==='all'?'ALL TIME*':state.period;
const periodDetail=()=>{let d=yr();return state.period==='all'?'AVAILABLE HISTORY · '+d.first.slice(0,10)+' – '+d.last.slice(0,10):d.first.slice(0,10)+' – '+d.last.slice(0,10)+' · PARTIAL YEAR'};
const header=tag=>`<div class="slide-header"><div class="mini-logo">take 5 deez<span style="opacity:.55">.</span></div><div>${esc(tag)}</div></div>`;
const bottom=(tag='THE RECEIPTS ARE REAL')=>`<div class="slide-bottom"><span>${esc(tag)}</span><span>✳ T5D WRAPPED</span></div>`;
function roast(a){const v=value(a.value,a.metric),n=a.winner;switch(a.id){
 case 'yapper':return `${n} sent ${v} messages. The group never subscribed to this newsletter.`;
 case 'clown':return `${v} Haha reactions. Some of those jokes even landed on purpose.`;
 case 'comedian':return `${v} laughs per 100 texts. A rare case of using the group chat effectively.`;
 case 'triple':return `${v} triple-text bursts. One bubble simply can't hold the entire thought.`;
 case 'killer':return `${v} silences followed a message from ${n}. Correlation is not causation. Allegedly.`;
 case 'resuscitator':return `${v} revivals. The chat tries to rest. ${n} simply won't allow it.`;
 case 'night':return `${v} texts between midnight and 5 AM. Sleep is clearly optional.`;
 case 'hater':return `${v} thumbs-downs given. Appointed themself quality control.`;
 case 'supplier':return `${v} attachment-filled texts. The unpaid content department.`;
 case 'novelist':return `${v} words per text on average. Nobody ordered the director's cut.`;
 default:return a.subhead}}
function ranking(metric){return Object.values(yr().stats).sort((a,b)=>b[metric]-a[metric]||b.messages-a.messages||N.indexOf(a.name)-N.indexOf(b.name));}
function cardMarkup(s){const p=yr();const h=header(topLabel());const foot=bottom();
 if(s.kind==='cover')return `${h}<div class="hero"><div class="slide-kicker">8 MEMBERS. 1 CHAT. ZERO SHAME.</div><h1 class="slide-title big">THE<br>CHAT<br>HAS<br>RECEIPTS.</h1><div class="year-huge">${state.period==='all'?'∞':state.period}</div><div class="slide-sub">THE TAKE 5 DEEZ<br>GROUP CHAT WRAPPED</div></div><div class="swirl"></div><div class="cover-ribbon">EVERY TEXT. EVERY BAD TAKE. ✳</div>${bottom('Swipe to expose the group →')}`;
 if(s.kind==='stats')return `${h}<div class="top-stats"><div class="slide-kicker">FIRST, THE DAMAGE.</div><h1 class="slide-title">A LOT WAS<br>SAID.</h1><div class="massive-number">${fmt(p.total_messages)}</div><div class="massive-caption">MESSAGES. NO REFUNDS.</div></div><div class="stat-grid"><div class="stat-tile"><b>${fmt(p.total_hahas_received)}</b><span>linked Haha reacts received</span></div><div class="stat-tile"><b>${fmt(p.total_linked_reactions_received)}</b><span>linked reactions received</span></div><div class="stat-tile"><b>${fmt(p.total_attachments)}</b><span>attachment-bearing messages</span></div><div class="stat-tile"><b>${fmt(p.active_days)}</b><span>calendar days active</span></div></div><div class="busy-tile"><small>THE SINGLE BUSIEST DAY</small><strong>${p.busiest_day?.date||'–'}</strong><span>${fmt(p.busiest_day?.count||0)} texts. Everybody log off.</span></div>${foot}`;
 if(s.kind==='leader'){
 const records=ranking(s.metric);const max=Math.max(1,records[0][s.metric]);
 let rows=records.map((r,i)=>`<div class="leader-row"><div class="leader-no">${String(i+1).padStart(2,'0')}</div><div class="leader-content"><div class="leader-name">${esc(r.name.toUpperCase())}</div><div class="bar-bg"><div class="bar-fill" style="width:${Math.max(.5,r[s.metric]/max*100)}%"></div></div></div><div class="leader-value">${value(r[s.metric],s.metric)}</div></div>`).join('');
 const punch=s.metric==='messages'?`${records[0].name} accounted for ${fmt(records[0].share,1)}% of the entire conversation.`:s.metric==='hahas_received'?`${records[0].name} collected the most laughs. Volume really is a strategy.`:`${records[0].name} tops the efficiency charts. Smaller sample, bigger punchlines.`;
 return `${h}<div class="leader-top"><div class="slide-kicker">THE OFFICIAL RANKINGS / 01–08</div><h1 class="slide-title">${s.title.replaceAll('\n','<br>')}</h1><div class="slide-sub">${esc(s.unit)}</div></div><div class="leader-wrap">${rows}</div><div class="leader-take">${esc(punch)}</div>${foot}`}
 if(s.kind==='award'){
 const a=award(s.award);
 return `${h}<div class="award-num">AWARD ${String(s.index+1).padStart(2,'0')} / 10</div><h1 class="slide-title award-head">${esc(a.title.toUpperCase())}</h1><div class="winner-wrap"><div class="winner-label">AND THE WINNER IS...</div><div class="winner-name">${esc(a.winner.toUpperCase())}.</div><div class="award-main-stat"><div class="award-val">${value(a.value,a.metric)}</div><div class="award-unit">${esc(a.unit)}</div></div></div><div class="roast-sticker">“${esc(roast(a))}”</div><div class="runner-up">RUNNER UP: ${esc(a.runner_up)} (${value(a.runner_value,a.metric)})${a.qualifier?' · '+esc(a.qualifier):''}</div>${foot}`}
 if(s.kind==='hall'){
 const q=p.top_text_messages.slice(0,5);const lines=q.map((m,i)=>`<button class="hall-row" data-quote="${esc(m.id)}"><div class="hall-row-top"><span>${i+1}. ${esc(m.member.toUpperCase())}</span><span class="hall-badge">😂 ${fmt(m.hahas)}</span></div><div class="hall-row-quote">${state.private?'🔒 Message hidden — tap to reveal in private mode off':esc('“'+m.quote+'”')}</div></button>`).join('');
 return `${h}<div class="hall-title"><div class="slide-kicker">THE MESSAGES THAT LANDED</div><h1 class="slide-title">ACTUAL<br>COMEDY.<br>ALLEGEDLY.</h1><div class="slide-sub">Top five readable texts by Haha reacts</div></div><div class="hall-list">${lines||'<p>No readable messages with linked Haha reacts.</p>'}</div><div class="hall-footnote">Tap a message to see the full quote. Media-only messages are excluded from this ranking.</div>${foot}`;
 }
 if(s.kind==='spotlight'){
 const quote=p.top_text_messages[0];const max=p.top_message;
 return `${h}<div class="spotlight-tag">THE FUNNIEST READABLE TEXT</div><h1 class="slide-title">THE TEXT<br>THAT HIT.</h1><div class="bubble"><div class="bubble-from">${esc(quote?.member.toUpperCase()||'NONE')} ✳</div><div class="bubble-text">${state.private?'🔒 PRIVATE MESSAGE HIDDEN':esc(quote?.quote||'No qualifying message')}</div><div class="bubble-react">😂 ${fmt(quote?.hahas||0)}</div></div><button class="spotlight-more" data-quote="${esc(quote?.id||'')}">READ FULL MESSAGE ↗</button><div class="spotlight-sub">${esc(quote?.date.slice(0,10)||'')}</div><div class="record-stamp" style="margin-top:auto;background:var(--ink);color:var(--bg);padding:3cqw;border-radius:2cqw;font:750 3cqw/1.4 var(--text)">ALL-MESSAGE RECORD: ${max?`${fmt(max.hahas)} Hahas · ${esc(max.member)}`:'—'}${max&&!max.quote?' · media preview unavailable':''}</div>${foot}`}
 if(s.kind==='shift'){
 const old=DB.periods['2025'],neu=DB.periods['2026'];const changes=N.map(n=>({n,old:old.stats[n].share,next:neu.stats[n].share,delta:Math.round((neu.stats[n].share-old.stats[n].share)*10)/10})).sort((a,b)=>Math.abs(b.delta)-Math.abs(a.delta));
 const rows=changes.map(x=>`<div class="year-row"><span>${esc(x.n)}</span><span>${fmt(x.old,1)}%</span><span>${x.delta>=0?'+':''}${fmt(x.delta,1)} pts</span></div>`).join('');
 return `${h}<div class="history-lead"><div class="slide-kicker">2025 → 2026 / SHARE OF CHAT</div><h1 class="slide-title">THE POWER<br>SHIFT.</h1><div class="slide-sub">Who took up more of the group chat?</div></div><div class="year-head"><span>MEMBER</span><span>2025 SHARE</span><span>CHANGE '26</span></div>${rows}<div class="history-callout">${esc(changes[0].n)} had the biggest shift: ${changes[0].delta>=0?'+':''}${fmt(changes[0].delta,1)} percentage points. Shares control for different yearly volumes.</div>${foot}`}
 if(s.kind==='champs'){
 const combos=[['Certified Yapper','yapper'],['Class Clown','clown'],['The Comedian','comedian']];
 const blocks=combos.map(([title,id])=>`<div class="champs-cell"><span>${esc(title.toUpperCase())}</span><strong>${esc(DB.periods['2025'].awards.find(a=>a.id===id).winner)}</strong><small>2025 champion</small></div><div class="champs-cell"><span>${esc(title.toUpperCase())}</span><strong>${esc(DB.periods['2026'].awards.find(a=>a.id===id).winner)}</strong><small>2026 champion</small></div>`).join('');
 const all=DB.periods.all;
 return `${h}<div class="history-lead"><div class="slide-kicker">THE HISTORICAL FILES</div><h1 class="slide-title">WHO HELD<br>THE CROWN?</h1><div class="slide-sub">Back-to-back winners or a change of guard?</div></div><div class="champs-grid">${blocks}</div><div class="record-stamp">ALL-TIME RECORD · ${fmt(all.total_messages)} texts in the available chat archive. 2025 starts in February; 2026 is year-to-date.</div>${foot}`}
 if(s.kind==='outro'){
 const counts={};p.awards.forEach(a=>counts[a.winner]=(counts[a.winner]||0)+1);
 const top=Object.entries(counts).sort((a,b)=>b[1]-a[1])[0];
 return `${h}<div class="outro-pre"><div class="slide-kicker">THE GROUP CHAT HAS SPOKEN</div><h1 class="slide-title big outro-main">THAT'S<br>A WRAP.</h1><div class="slide-sub">We learned absolutely nothing. Except who's responsible.</div></div><div class="outro-box"><div class="winner-label">MOST AWARDS WON THIS ERA</div><div class="outro-winner">${esc(top[0].toUpperCase())}</div><div class="outro-caption">${top[1]} OUT OF 10 TITLES.<br>THIS IS AN INTERVENTION.</div></div><div class="outro-foot">8 FRIENDS. ${fmt(p.total_messages)} MESSAGES.<br>AN UNHEALTHY AMOUNT OF EVIDENCE.</div>${bottom('SEND IT TO THE CHAT. GOOD LUCK.')}`}
 return `${h}<p>Not yet available</p>${foot}`;
}
function detailFor(s){const p=yr();
 if(s.kind==='award'){const a=award(s.award);return {title:a.title,info:`${a.winner} takes the ${topLabel()} title. The winner is determined by the actual chat records, not a vote.`,facts:[`Winning metric: ${a.unit}.`,`Runner-up: ${a.runner_up} (${value(a.runner_value,a.metric)}).`,a.qualifier||'Ties break using message count, then fixed roster order.']}}
 if(s.kind==='leader'){const top=ranking(s.metric)[0];return{title:s.label,info:`Every member is ranked for ${topLabel()}. Tap another year to recalculate the order.`,facts:[`First place: ${top.name}.`,`Metric: ${s.unit}.`,'Haha received excludes reactions that cannot be matched to an original message.']}}
 if(s.kind==='cover')return{title:'The opening act',info:`Meet Take 5 deez Wrapped — eight members, real statistics, and the receipts nobody asked for.`,facts:[periodDetail(),'Browse the deck with the arrows, keyboard, or swiping on mobile.','Download any slide as a vertical PNG.']};
 if(s.kind==='stats')return{title:'By the numbers',info:'A high-level audit of the group chat for your selected era.',facts:['Message counts exclude reaction-only event records.','Reaction totals are linked to actual message recipients.','Attachment count is based on message flags, not individual photos.']};
 if(s.kind==='hall'||s.kind==='spotlight')return{title:s.label,info:'Actual messages, not generated jokes. These quotes are private and should be reviewed before forwarding.',facts:['The Hall ranks readable messages by linked Haha reactions.','Some higher-reacted-to records are photos or other unavailable media.','Tap a quote to see its longer text.']};
 if(s.kind==='shift'||s.kind==='champs')return{title:s.label,info:'Historical comparisons across the two available years. This snapshot includes partial-year coverage.',facts:['2025 begins February 4.','2026 ends October 11.','Shares and efficiency rates are more comparable than raw full-year totals.']};
 return{title:s.label,info:'Every winner is based on records from the selected period.',facts:['Award counts can include multiple wins by one person.',periodDetail()]};
}
function render(){const s=c(),p=yr();
 el('stage').innerHTML=`<article class="slide slide--${s.kind==='shift'||s.kind==='champs'?'history':s.kind}" ${themed(s)} aria-label="${esc(s.label)}">${cardMarkup(s)}</article>`;
 el('periodSelect').innerHTML=DB.meta.periods.map(x=>`<button class="period-btn ${x===state.period?'active':''}" data-period="${x}" aria-pressed="${x===state.period}">${x==='all'?'All time':esc(x)}</button>`).join('');
 const details=detailFor(s);el('detailTitle').textContent=details.title;el('detailInfo').textContent=details.info;el('sectionFacts').innerHTML=details.facts.filter(Boolean).map(x=>`<div class="fact-row"><i class="fact-dot"></i><span>${esc(x)}</span></div>`).join('');
 el('slideNumber').textContent=String(state.index+1).padStart(2,'0')+' / '+String(slides.length).padStart(2,'0');el('slideCategory').textContent=s.group;el('progressFill').style.width=`${100*(state.index+1)/slides.length}%`;
 el('prevButton').disabled=state.index===0;el('nextButton').disabled=state.index===slides.length-1;
 el('privacyButton').classList.toggle('is-private',state.private);el('privacyButton').textContent=state.private?'◎':'◉';el('privacyButton').setAttribute('aria-label',state.private?'Show private quotes':'Hide private quotes');
 el('slideNav').querySelectorAll('.nav-item').forEach(btn=>btn.setAttribute('aria-current',String(Number(btn.dataset.idx)===state.index?'step':'false')));
 el('slideNav').querySelector(`[data-idx="${state.index}"]`)?.scrollIntoView({block:'nearest',behavior:'smooth'});
}
function buildNav(){let group='';let html='';slides.forEach((s,i)=>{if(s.group!==group){if(group)html+='</div>';group=s.group;html+=`<div class="nav-group"><div class="nav-label">${esc(group)}</div>`;}html+=`<button class="nav-item" data-idx="${i}" aria-current="false"><span class="nav-num">${String(i+1).padStart(2,'0')}</span><span class="nav-text">${esc(s.label)}</span><span class="nav-active">${s.kind==='award'?'✳':''}</span></button>`;});el('slideNav').innerHTML=html+'</div>';}
function goto(i){state.index=Math.max(0,Math.min(slides.length-1,i));render()}
function selectedQuote(id){const o=yr().top_text_messages.find(x=>x.id===id);if(!o)return;
 if(state.private){toast('Turn off privacy mode to read private quotes.');return}
 el('modalTitle').textContent=o.member;el('modalText').textContent=o.quote;el('modalMeta').textContent=`${o.date} · ${o.hahas} Haha reactions · ${o.reactions} linked reactions`;
 el('quoteOverlay').hidden=false;el('modalClose').focus();}
function closeQuote(){el('quoteOverlay').hidden=true;el('stage').focus?.()}
let toastTimer=null;function toast(text){const div=el('toast');div.textContent=text;div.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>div.classList.remove('show'),2700)}
function resultText(){const s=c(),p=yr();let title='TAKE 5 DEEZ WRAPPED · '+topLabel()+'\n';if(s.kind==='award'){const a=award(s.award);return title+`${a.title}: ${a.winner} — ${value(a.value,a.metric)} ${a.unit}.\n${roast(a)}`}
 if(s.kind==='leader'){return title+s.label+'\n'+ranking(s.metric).map((x,i)=>`${i+1}. ${x.name}: ${value(x[s.metric],s.metric)}`).join('\n')}
 if(s.kind==='stats')return title+`${fmt(p.total_messages)} messages; ${fmt(p.total_hahas_received)} linked Haha reacts; ${fmt(p.total_attachments)} attachment-bearing messages.`;
 if(s.kind==='hall'||s.kind==='spotlight'){return state.private?title+'Hall of Fame (private quotes hidden)':title+p.top_text_messages.slice(0,s.kind==='hall'?5:1).map((x,i)=>`${i+1}. ${x.member} (${x.hahas} Haha): “${x.quote}”`).join('\n')}
 return title+s.label+'\n'+periodDetail();}

// Browser-local image export; the export is drawn onto an actual canvas so it also
// works when the site is opened from file:// without screenshot services or dependencies.
async function exportPNG(){const s=c(),p=yr(),theme=colors[s.theme];await (document.fonts?.ready||Promise.resolve());const canvas=document.createElement('canvas');const W=1080,H=1920;canvas.width=W;canvas.height=H;const ctx=canvas.getContext('2d');
 const round=(x,y,w,h,r,fill)=>{ctx.fillStyle=fill;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill()};
 const txt=(text,x,y,size,weight=700,color=theme.ink,align='left')=>{ctx.fillStyle=color;ctx.textAlign=align;ctx.font=`${weight} ${size}px 'Space Grotesk', 'Avenir Next', sans-serif`;ctx.fillText(String(text),x,y);ctx.textAlign='left'};
 const lines=(text,x,y,maxWidth,size,lineHeight=1.15,weight=700,color=theme.ink,maxLines=99)=>{ctx.font=`${weight} ${size}px 'Space Grotesk','Avenir Next',sans-serif`;const paragraphs=String(text).split('\n');let j=0;for(const paragraph of paragraphs){let words=paragraph.split(/\s+/),line='';for(const w of words){const next=line?line+' '+w:w;if(ctx.measureText(next).width>maxWidth && line){if(j>=maxLines)return y+j*size*lineHeight;txt(line,x,y+j*size*lineHeight,size,weight,color);j++;line=w;}else line=next}if(line){if(j>=maxLines)return y+j*size*lineHeight;txt(line,x,y+j*size*lineHeight,size,weight,color);j++;}}return y+j*size*lineHeight;};
 round(0,0,W,H,0,theme.bg);
 ctx.lineWidth=82;ctx.strokeStyle=theme.orb;ctx.beginPath();ctx.arc(1120,-80,400,0,Math.PI*2);ctx.stroke();ctx.fillStyle=theme.blob;ctx.beginPath();ctx.ellipse(-80,1740,330,270,-.5,0,Math.PI*2);ctx.fill();
 txt('take 5 deez.',75,110,40,900);txt(topLabel(),1000,110,30,800,theme.ink,'right');
 if(s.kind==='cover'){txt('8 MEMBERS · 1 GROUP CHAT',80,315,42,800);lines('THE CHAT HAS RECEIPTS.',70,500,950,145,.97,700);txt(state.period==='all'?'∞':state.period,80,1080,300,700);round(65,1380,960,190,15,theme.ink);txt('EVERY TEXT. EVERY BAD TAKE.',105,1499,62,800,theme.bg);txt('THE TAKE 5 DEEZ GROUP CHAT WRAPPED',80,1760,34,800)}
 else if(s.kind==='stats'){lines('A LOT WAS SAID.',75,285,950,115,.95);txt(fmt(p.total_messages),70,650,190,700);txt('MESSAGES. NO REFUNDS.',75,715,45,800);const stats=[[fmt(p.total_hahas_received),'LINKED HAHAS'],[fmt(p.total_linked_reactions_received),'LINKED REACTIONS'],[fmt(p.total_attachments),'ATTACHMENT MESSAGES'],[fmt(p.active_days),'ACTIVE DAYS']];stats.forEach((a,i)=>{let x=75+i%2*475,y=815+Math.floor(i/2)*290;round(x,y,445,255,22,'#ffffff65');txt(a[0],x+27,y+108,95,700);txt(a[1],x+27,y+194,28,800)});round(75,1450,940,260,22,theme.ink);txt('SINGLE BUSIEST DAY',110,1520,34,800,theme.bg);txt(p.busiest_day.date,110,1620,76,700,theme.bg);txt(p.busiest_day.count+' messages',110,1680,30,700,theme.bg)}
 else if(s.kind==='leader'){lines(s.title.replaceAll('\n',' '),75,290,935,105,.94);txt(s.unit.toUpperCase(),75,525,37,750);const r=ranking(s.metric),max=Math.max(1,r[0][s.metric]);r.forEach((a,i)=>{const y=650+i*133;txt(String(i+1).padStart(2,'0'),75,y,41);txt(a.name.toUpperCase(),153,y,46,800);round(153,y+16,630,17,8,'#15102024');round(153,y+16,630*a[s.metric]/max,17,8,i===0?theme.special:theme.ink);txt(value(a[s.metric],s.metric),1000,y,42,700,theme.ink,'right')});}
 else if(s.kind==='award'){const a=award(s.award);txt('AWARD '+String(s.index+1).padStart(2,'0')+' / 10',75,300,40,800);let end=lines(a.title.toUpperCase(),70,440,950,118,.94,700);txt('AND THE WINNER IS...',77,790,38,800);txt(a.winner.toUpperCase()+'.',70,960,a.winner.length>6?115:155,700);txt(value(a.value,a.metric),70,1210,190,700);lines(a.unit.toUpperCase(),76,1280,850,41,1.2,750);round(70,1390,940,300,23,theme.ink);lines('“'+roast(a)+'”',105,1477,860,51,1.3,750,theme.bg,4);txt('RUNNER UP: '+a.runner_up+' ('+value(a.runner_value,a.metric)+')',80,1770,32,800);}
 else if(s.kind==='hall'){lines('ACTUAL COMEDY. ALLEGEDLY.',70,270,950,106,.92);txt('TOP FIVE READABLE TEXTS BY HAHA',75,535,32,800);p.top_text_messages.slice(0,5).forEach((a,i)=>{const y=620+i*220;round(70,y,940,196,16,'#ffffff70');txt(`${i+1}. ${a.member.toUpperCase()}`,90,y+50,43,800);txt('😂 '+a.hahas,980,y+50,37,700,theme.ink,'right');lines(state.private?'[QUOTE HIDDEN]':a.quote,90,y+100,870,32,1.18,650,theme.ink,2)});txt('MEDIA MESSAGES ARE EXCLUDED FROM THIS LIST.',75,1810,28,700);}
 else if(s.kind==='spotlight'){lines('THE TEXT THAT HIT.',70,290,940,115,.93);const a=p.top_text_messages[0];round(75,700,925,740,35,'#ffffffaa');txt(a?.member.toUpperCase()||'—',115,810,60,800);lines(state.private?'PRIVATE QUOTE HIDDEN':a?.quote||'None',115,905,830,61,1.27,650,theme.ink,6);txt('😂 '+(a?.hahas||0),910,1360,55,800,theme.ink,'right');txt('OVERALL MESSAGE RECORD: '+(p.top_message?.hahas||0)+' HAHAS',80,1550,42,800);if(p.top_message&&!p.top_message.quote)txt('RECORD HOLDER SENT AN UNAVAILABLE MEDIA MESSAGE.',80,1620,28,650);}
 else if(s.kind==='shift'){lines('THE POWER SHIFT.',70,295,940,112,.95);txt('SHARE OF GROUP MESSAGES',75,520,36,800);const x=N.map(n=>({n,old:DB.periods['2025'].stats[n].share,newv:DB.periods['2026'].stats[n].share})).sort((a,b)=>Math.abs(b.newv-b.old)-Math.abs(a.newv-a.old));txt('MEMBER',75,620,28,800);txt('2025',540,620,28,800);txt('2026',760,620,28,800);x.forEach((a,i)=>{const y=695+i*135;txt(a.n,75,y,44,700);txt(fmt(a.old,1)+'%',530,y,39,700);txt(fmt(a.newv,1)+'%',780,y,39,700);ctx.fillStyle=theme.ink;ctx.fillRect(70,y+30,920,2)});txt('BOTH YEARS HAVE PARTIAL COVERAGE',75,1790,30,800);}
 else if(s.kind==='champs'){lines('WHO HELD THE CROWN?',70,295,930,108,.95);const ids=['yapper','clown','comedian'];ids.forEach((id,i)=>{let y=640+i*335;const a=DB.periods['2025'].awards.find(q=>q.id===id),b=DB.periods['2026'].awards.find(q=>q.id===id);round(70,y,935,300,20,'#ffffff77');txt(a.title.toUpperCase(),95,y+75,42,800);txt('2025',95,y+140,29,800);txt('2026',580,y+140,29,800);txt(a.winner,95,y+228,64,700);txt(b.winner,580,y+228,64,700)});txt('2025 AND 2026 ARE PARTIAL YEARS',75,1770,28,800);}
 else if(s.kind==='outro'){lines("THAT'S A WRAP.",70,390,950,160,.95);txt('8 FRIENDS. ZERO SHAME.',75,730,43,800);const counts={};p.awards.forEach(a=>counts[a.winner]=(counts[a.winner]||0)+1);const top=Object.entries(counts).sort((a,b)=>b[1]-a[1])[0];round(70,900,940,560,24,theme.ink);txt('MOST AWARDS WON',110,1010,40,800,theme.bg);txt(top[0].toUpperCase(),105,1195,140,700,theme.bg);txt(`${top[1]} / 10 TITLES`,110,1310,75,800,theme.bg);txt('AN UNHEALTHY AMOUNT OF EVIDENCE.',78,1660,37,800);}
 txt('TAKE 5 DEEZ WRAPPED  ✳',75,1862,27,800);txt(String(state.index+1).padStart(2,'0')+' / 20',990,1862,27,800,theme.ink,'right');
 const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob){toast('PNG export failed. Try another browser.');return}
 const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download=`take5-${state.period}-${String(state.index+1).padStart(2,'0')}-${s.id}.png`;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(link.href),1000);toast('Saved 1080 × 1920 PNG card.');
}
// Event wiring
buildNav();render();
el('slideNav').addEventListener('click',e=>{const btn=e.target.closest('[data-idx]');if(btn)goto(Number(btn.dataset.idx))});
el('periodSelect').addEventListener('click',e=>{const btn=e.target.closest('[data-period]');if(btn){state.period=btn.dataset.period;render()}});
el('prevButton').addEventListener('click',()=>goto(state.index-1));el('nextButton').addEventListener('click',()=>goto(state.index+1));
el('privacyButton').addEventListener('click',()=>{state.private=!state.private;render()});
el('downloadButton').addEventListener('click',()=>{exportPNG().catch(err=>{console.error(err);toast('PNG export unavailable — check the browser console.')})});
el('copyButton').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(resultText());toast('Result copied.')}catch(e){const ta=document.createElement('textarea');ta.value=resultText();ta.style.position='fixed';ta.style.left='-9999px';document.body.append(ta);ta.select();const ok=document.execCommand('copy');ta.remove();toast(ok?'Result copied.':'Clipboard unavailable in this browser.')}});
el('stage').addEventListener('click',e=>{const btn=e.target.closest('[data-quote]');if(btn)selectedQuote(btn.dataset.quote)});
el('modalClose').addEventListener('click',closeQuote);el('quoteOverlay').addEventListener('click',e=>{if(e.target===el('quoteOverlay'))closeQuote()});
document.addEventListener('keydown',e=>{if(!el('quoteOverlay').hidden){if(e.key==='Escape')closeQuote();return;}if(e.target.closest('button')&&['ArrowLeft','ArrowRight'].includes(e.key))return;if(e.key==='ArrowRight')goto(state.index+1);if(e.key==='ArrowLeft')goto(state.index-1)});
let touchStart=null;el('stage').addEventListener('touchstart',e=>{touchStart={x:e.changedTouches[0].clientX,y:e.changedTouches[0].clientY}},{passive:true});el('stage').addEventListener('touchend',e=>{if(!touchStart)return;const dx=e.changedTouches[0].clientX-touchStart.x,dy=e.changedTouches[0].clientY-touchStart.y;if(Math.abs(dx)>55&&Math.abs(dx)>Math.abs(dy)*1.6){goto(state.index+(dx<0?1:-1))}touchStart=null},{passive:true});
})();
