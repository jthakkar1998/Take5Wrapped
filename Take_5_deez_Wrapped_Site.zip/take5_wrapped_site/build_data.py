#!/usr/bin/env python3
"""Build the entirely local Take 5 deez Wrapped dataset.

python3 build_data.py --csv take5_wrapped_enriched.csv
python3 build_data.py --db /path/to/copied/chat.db --chat-id 1731

No external packages or network requests. Only selected chat data is read.
"""
from __future__ import annotations
import argparse,csv,datetime,json,re,sqlite3,sys
from collections import Counter,defaultdict
from pathlib import Path
from urllib.parse import quote

HERE=Path(__file__).resolve().parent
MEMBERS={"0":"Jay","4":"Nikhil","5":"Amar","15":"Nathan","17":"Shil","121":"Anoop","214":"Neal","217":"Purav"}
NAMES=["Jay","Shil","Amar","Anoop","Neal","Nikhil","Purav","Nathan"]
REACTIONS={"2000":"love","2001":"like","2002":"dislike","2003":"haha","2004":"emphasize","2005":"question","2006":"other_tapback"}
AWARDS=[
  ("yapper","Certified Yapper","messages","messages","The microphone was never yours. You took it anyway.","volume"),
  ("clown","Class Clown","hahas_received","Haha reacts received","People actually laughed. The evidence is undeniable.","comedy"),
  ("comedian","The Comedian","hahas_rate","Haha reacts per 100 messages","Less talking. More landing.","comedy"),
  ("triple","Triple Text Menace","triple_runs","3+ bubble streaks (within 30 min)","Apparently one message bubble is never enough.","chaos"),
  ("killer","Conversation Killer","silences","6+ hour gaps after their text","Correlation isn't causation. But it's not a good look.","chaos"),
  ("resuscitator","The Resuscitator","revivals","6+ hour silences broken","The group tries to rest. This person will not allow it.","chaos"),
  ("night","Midnight Menace","late_texts","messages sent midnight–5 AM","Sleep is a suggestion.","chaos"),
  ("hater","Professional Hater","dislikes_given","thumbs-down reacts given","The unsolicited quality assurance department.","chaos"),
  ("supplier","Content Supplier","attachment_messages","messages with attachments","For every occasion, an attachment.","volume"),
  ("novelist","The Novelist","avg_words","average words per text message","Nobody ordered the director's cut.","volume")
]

def read_enriched(path):
    with open(path,encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f))

def decode_body(hex_or_bytes):
    """Decode common NSAttributedString typedstream NSString, on a best-effort basis."""
    if not hex_or_bytes:return ''
    blob=bytes.fromhex(hex_or_bytes) if isinstance(hex_or_bytes,str) else hex_or_bytes
    mark=b'\x84\x01+'
    p=blob.index(mark)+len(mark);lead=blob[p]
    if lead<128:n,start=lead,p+1
    elif lead==0x81:n,start=int.from_bytes(blob[p+1:p+3],'little'),p+3
    elif lead==0x82:n,start=int.from_bytes(blob[p+1:p+5],'little'),p+5
    else:raise ValueError('Unknown string length marker')
    stop=start+n
    if stop>len(blob) or blob[stop:stop+2]!=b'\x86\x84':raise ValueError('Invalid string boundary')
    return blob[start:stop].decode('utf-8')

def read_db(path,chat_id):
    # Point at a local, copied snapshot. Never write to the user's Messages database.
    uri='file:'+quote(str(Path(path).expanduser().resolve()))+'?mode=ro'
    db=sqlite3.connect(uri,uri=True)
    try:
        rec=db.execute('''SELECT m.ROWID,m.guid,m.date,m.is_from_me,m.handle_id,
                          m.text,m.associated_message_type,m.associated_message_guid,
                          m.cache_has_attachments,m.attributedBody
                          FROM message m JOIN chat_message_join j ON j.message_id=m.ROWID
                          WHERE j.chat_id=? ORDER BY m.date, m.ROWID''',(chat_id,)).fetchall()
    finally: db.close()
    if not rec:raise ValueError('No messages for that chat ID. Check the database and chat ID.')
    norm=[]
    for mid,guid,date,from_me,hid,txt,react,react_guid,attachment,body in rec:
        is_rx=int(react or 0)
        try:
            readable=txt if txt else decode_body(body)
        except (ValueError,IndexError,UnicodeDecodeError):readable=txt or ''
        # Apple's date is ns since 2001-01-01; local zone is the machine running conversion.
        dt=datetime.datetime.fromtimestamp(float(date)/1e9+978307200).strftime('%Y-%m-%d %H:%M:%S')
        ident='0' if from_me else str(hid or '')
        norm.append({'message_id':str(mid),'message_guid':guid or '',
             'timestamp':str(date),'message_date':dt,'member':MEMBERS.get(ident,f'Unmapped ({ident})'),
             'record_type':'message' if not is_rx else ('tapback' if str(is_rx) in REACTIONS else 'other_event'),
             'reaction_name':REACTIONS.get(str(is_rx),''),'reacted_to_guid':react_guid or '',
             'message_text':readable or '','has_attachment':str(attachment or 0)})
    return norm

def collect(rows):
    """Normalize sender and reaction linking; accept both enriched CSV and direct DB rows."""
    clean=[]
    for row in rows:
        x=row.copy()
        if 'member' not in x:
            x['member']=MEMBERS.get(x.get('sender_id',''), 'Unmapped')
        if 'record_type' not in x:
            typ=str(x.get('reaction_type','0'))
            x['record_type']='message' if typ=='0' else ('tapback' if typ in REACTIONS else 'other_event')
        if 'reaction_name' not in x:
            x['reaction_name']=REACTIONS.get(str(x.get('reaction_type','0')),'')
        x['year']=x['message_date'][:4]
        x['timestamp']=int(x['timestamp'])
        x['message_id']=str(x['message_id'])
        x['has_attachment']=str(x.get('has_attachment','0'))
        x['message_text']=x.get('message_text') or ''
        clean.append(x)
    if not clean:raise ValueError('The selected CSV is empty.')
    message_map={x['message_guid']:x for x in clean if x['record_type']=='message'}
    for x in clean:
        if x['record_type']=='tapback':
            ref=x.get('reacted_to_guid','')
            key=ref.split('/',1)[-1] if '/' in ref else ref
            target=message_map.get(key)
            x['target']=target
        else: x['target']=None
    return clean

def wordcount(s):
    return len(re.findall(r"\b\w+(?:['’]\w+)*\b", s.replace('\ufffc',' '),re.UNICODE))

def compact_quote(s):
    s=s.replace('\ufffc',' [attachment] ').strip()
    s=re.sub(r'\s+',' ',s)
    return s

def build(rows,chat_id):
    rows=collect(rows)
    messages=sorted((r for r in rows if r['record_type']=='message'),key=lambda x:(x['timestamp'],int(x['message_id'])))
    taps=[r for r in rows if r['record_type']=='tapback']
    mapped_msgs=[r for r in messages if r['member'] in NAMES]
    if len(mapped_msgs)<100:raise ValueError('Not enough mapped messages; check chat ID and sender mapping.')
    per_target=defaultdict(lambda:Counter())
    for t in taps:
        if t['target'] and t['target']['member'] in NAMES:
            per_target[t['target']['message_id']][t['reaction_name']]+=1
    # Derive runs and hiatus boundaries on the full timeline, not independently for each year.
    triples=Counter();longest=Counter();ends=Counter();revives=Counter()
    run_member=None;run_len=0;prev=None
    def finish_run():
        if run_member in NAMES:
            if run_len>=3:triples[(run_member,run_start_year)]+=1
            longest[(run_member,run_start_year)]=max(longest[(run_member,run_start_year)],run_len)
    for m in messages:
        name=m['member']
        if prev is not None:
            gap=(m['timestamp']-prev['timestamp'])/1e9/3600
            if gap>=6:
                if prev['member'] in NAMES:ends[(prev['member'],prev['year'])]+=1
                if name in NAMES:revives[(name,m['year'])]+=1
        if name==run_member and m['year']==run_start_year and prev is not None and (m['timestamp']-prev['timestamp'])/1e9<=1800:
            run_len+=1
        else:
            if run_member is not None:finish_run()
            run_member=name;run_len=1;run_start_year=m['year']
        prev=m
    if run_member is not None:finish_run()
    source_start=messages[0]['message_date'];source_end=messages[-1]['message_date']
    periods={}
    options=sorted(set(m['year'] for m in mapped_msgs))+['all']
    for period in options:
        belongs=lambda x:period=='all' or x['year']==period
        mm=[m for m in mapped_msgs if belongs(m)]
        rx_in=[t for t in taps if belongs(t)]
        recvd=[t for t in taps if t['target'] and t['target']['member'] in NAMES and belongs(t['target'])]
        stats={name:{'name':name,'messages':0,'hahas_received':0,'hahas_rate':0.0,
                     'reactions_received':0,'hahas_given':0,'dislikes_given':0,'late_texts':0,
                     'attachment_messages':0,'avg_words':0.0,'words_total':0,'text_count':0,
                     'triple_runs':0,'longest_streak':0,'silences':0,'revivals':0,'active_days':0,'share':0}
               for name in NAMES}
        days=defaultdict(set)
        for m in mm:
            s=stats[m['member']];s['messages']+=1
            d=m['message_date'][:10];days[m['member']].add(d)
            hour=int(m['message_date'][11:13]);s['late_texts']+=int(0<=hour<5)
            s['attachment_messages']+=int(m['has_attachment']=='1')
            wc=wordcount(m['message_text'])
            if wc>0:
                s['words_total']+=wc;s['text_count']+=1
        for t in rx_in:
            if t['member'] not in stats:continue
            if t['reaction_name']=='haha': stats[t['member']]['hahas_given']+=1
            if t['reaction_name']=='dislike':stats[t['member']]['dislikes_given']+=1
        for t in recvd:
            target=t['target'];s=stats[target['member']]
            s['reactions_received']+=1
            if t['reaction_name']=='haha':s['hahas_received']+=1
        for name,s in stats.items():
            years=([period] if period!='all' else sorted(set(x['year'] for x in messages)))
            s['triple_runs']=sum(triples[(name,y)] for y in years)
            s['longest_streak']=max((longest[(name,y)] for y in years),default=0)
            s['silences']=sum(ends[(name,y)] for y in years)
            s['revivals']=sum(revives[(name,y)] for y in years)
            s['active_days']=len(days[name])
            s['hahas_rate']=round(100*s['hahas_received']/s['messages'],2) if s['messages'] else 0
            s['avg_words']=round(s['words_total']/s['text_count'],1) if s['text_count'] else 0
            s['share']=round(100*s['messages']/len(mm),1) if mm else 0
        quote_candidates=[]
        for m in mm:
            rc=per_target[m['message_id']]
            quote=compact_quote(m['message_text'])
            quoted=bool(quote and quote!='[attachment]')
            quote_candidates.append({'id':m['message_id'],'member':m['member'],
                 'date':m['message_date'],'quote':quote if quoted else '',
                 'media':m['has_attachment']=='1' or '\ufffc' in m['message_text'],
                 'hahas':rc['haha'],'reactions':sum(rc.values())})
        sorted_hof=sorted(quote_candidates,key=lambda x:(-x['hahas'],-x['reactions'],x['date'],x['id']))
        quotes=[x for x in sorted_hof if x['quote'] and x['hahas']>0][:12]
        highest=sorted_hof[0] if sorted_hof else None
        per_day=Counter(m['message_date'][:10] for m in mm)
        months=Counter(m['message_date'][:7] for m in mm)
        first=mm[0]['message_date'] if mm else '';last=mm[-1]['message_date'] if mm else ''
        awards=[]
        for ident,title,metric,unit,subhead,category in AWARDS:
            qualifiers=[s for s in stats.values() if s['messages']>=100] if ident=='comedian' else list(stats.values())
            ranking=sorted(qualifiers,key=lambda s:(-s[metric],-s['messages'],NAMES.index(s['name'])))
            winner=ranking[0];other=ranking[1] if len(ranking)>1 else None
            awards.append({'id':ident,'title':title,'metric':metric,'unit':unit,'winner':winner['name'],
                           'value':winner[metric],'runner_up':other['name'] if other else '',
                           'runner_value':other[metric] if other else 0,'subhead':subhead,'category':category,
                           'qualifier':'Minimum 100 messages' if ident=='comedian' else ''})
        periods[period]={
            'label':'ALL TIME' if period=='all' else period,
            'first':first,'last':last,'total_messages':len(mm),
            'total_hahas_received':sum(x['hahas_received'] for x in stats.values()),
            'total_linked_reactions_received':len(recvd),
            'total_attachments':sum(x['attachment_messages'] for x in stats.values()),
            'total_reactions_given':len(rx_in),
            'active_days':len(per_day),
            'busiest_day':{'date':per_day.most_common(1)[0][0],'count':per_day.most_common(1)[0][1]} if per_day else None,
            'stats':stats,'awards':awards,'top_text_messages':quotes,
            'top_message':highest, 'months':dict(sorted(months.items()))}
    all_rx=sum(1 for x in taps if x['reaction_name']=='haha')
    linked_haha=sum(1 for x in taps if x['reaction_name']=='haha' and x['target'])
    return {'meta':{
        'title':'Take 5 deez Wrapped','chat_id':chat_id,'members':NAMES,'first_record':source_start,'last_record':source_end,
        'record_count':len(rows),'message_records':len(messages),'mapped_messages':len(mapped_msgs),
        'hahas_raw':all_rx,'hahas_linked':linked_haha,
        'unlinked_hahas':all_rx-linked_haha,
        'unlinked_tapbacks':sum(1 for x in taps if not x['target']),
        'unknown_senders':len(messages)-len(mapped_msgs),
        'missing_text':sum(1 for m in messages if not m['message_text'].strip()),
        'notes':['Data includes only chat ID 1731; other similarly named chats are excluded.',
        '2025 starts in February and 2026 ends on October 11; both are partial calendar years.',
        'Reactions received are credited to the year in which the original message was sent.',
        'Some reactions cannot be linked to messages; awards omit those unlinked reactions.',
        'Attachment counts represent messages flagged with attachments, not individual files.',
        'Hall of Fame message text is taken from private chat history; review before sharing.'],
        'periods':options},'periods':periods}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    src=p.add_mutually_exclusive_group(required=True)
    src.add_argument('--csv',type=Path,help='Enriched CSV generated from earlier export')
    src.add_argument('--db',type=Path,help='Copied chat.db from your Mac (never the live DB)')
    p.add_argument('--chat-id',type=int,default=1731)
    p.add_argument('--output',type=Path,default=HERE/'app-data.js')
    args=p.parse_args()
    rows=read_db(args.db,args.chat_id) if args.db else read_enriched(args.csv)
    data=build(rows,args.chat_id)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text('window.TAKE5_DATA = '+json.dumps(data,ensure_ascii=True,separators=(',',':'))+';\n',encoding='utf-8')
    print(f"Wrote {args.output} ({args.output.stat().st_size:,} bytes)")
    print(f"{data['meta']['mapped_messages']:,} messages; {data['meta']['hahas_linked']:,}/{data['meta']['hahas_raw']:,} linked haha reacts")
    for y,dat in data['periods'].items():
        print(y,'msgs',dat['total_messages'],'awards',[(a['title'],a['winner'],a['value']) for a in dat['awards']])

if __name__=='__main__':main()
