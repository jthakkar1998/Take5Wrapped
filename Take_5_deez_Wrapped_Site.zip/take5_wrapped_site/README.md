# Take 5 deez Wrapped — First Interactive Prototype

A private, locally runnable 20-card Spotify-Wrapped-inspired group-chat analysis.

## Quick start on your Mac

**Easiest option:** double-click `Take_5_deez_Wrapped.html` (provided separately). It opens in Safari or Chrome. No installation or web server needed.

**Updater-friendly option:** unzip `Take_5_deez_Wrapped_Site.zip`, open the `take5_wrapped_site` folder, and double-click `index.html`. Keep `index.html`, `style.css`, `app.js`, and `app-data.js` together.

Use the **2025 / 2026 / All time** control at the top to switch years. Each period recalculates the 3 leaderboards, 10 awards, Hall of Fame, and records. Use the arrow buttons, sidebar (desktop), left/right keyboard arrows, or swipe gestures (mobile) to navigate. **Save card as PNG** exports a 1080 × 1920 image of the current card. **Copy the result** copies the active ranking or award text.

The small circle button near the year control hides or reveals the private message quotes. This is a *display convenience*, not security or encryption.

## Refresh when your Mac has newer Messages data

1. In Messages > Settings > iMessage, sync messages. Quit Messages.
2. Refresh the **copied** database, not the live one. In Terminal on the Mac:

   ```bash
   cp ~/Library/Messages/chat.db* ~/Desktop/Take5Export/
   ```

   Terminal needs Full Disk Access; copy alongside the `chat.db-wal` and `chat.db-shm` files if they exist.
3. In Terminal, go to the unzipped site folder, e.g.:

   ```bash
   cd ~/Downloads/take5_wrapped_site
   python3 build_data.py --db ~/Desktop/Take5Export/chat.db --chat-id 1731
   ```

   This rewrites `app-data.js` with fresh statistics and selected top-message quotes. It does **not** modify the Messages database.
4. Close and reopen `index.html` in the browser (or refresh, using a hard reload if cached).
5. To recreate the single-file HTML version, in the same site folder run:

   ```bash
   python3 make_standalone.py
   ```

   This generates a new `Take_5_deez_Wrapped.html` **one folder above** the site folder. It contains the latest processed data.

If a future Messages update changes the underlying Chat ID from `1731`, or changes the database schema, you may need to update the command or extraction script. You can instead process the existing enriched export using `python3 build_data.py --csv /path/to/take5_wrapped_enriched.csv`.

## Coverage and counting rules

- **2025**: February 4 – December 28, 2025, *partial history*.
- **2026**: January 9 – October 11, 2026, *year-to-date snapshot*.
- **All time** means **all history available in this single exported chat**, not every conversation ever called Take 5 deez.
- 12,213 mapped non-reaction messages, plus 1 non-reaction record with an unmapped sender.
- 1,006 of 1,024 Haha reaction records are attributable to original messages. The other 18 aren't assigned to a recipient.
- Received reactions are attributed to the **year of the original message**. Given reactions are attributed to the year the reaction was made.
- Message volume includes all ordinary message records, including some attachment-only entries.
- Haha efficiency = linked Haha reactions received per 100 ordinary messages, minimum **100 messages** to be eligible.
- "Triple Text Menace" counts runs of 3+ same-sender messages, continuing only when the gap between adjacent bubbles is at most 30 minutes. Runs are assigned to the year they began.
- "Conversation Killer" and "The Resuscitator" are based on pauses of at least 6 hours. These are playful correlational labels, not statements that someone caused the silence.
- "Midnight Menace" assumes the message timestamps in the CSV reflect the Mac's local timezone at export.
- "Content Supplier" counts messages **flagged** as having attachments, not the number of actual images, videos, or GIFs.
- "The Novelist" averages word counts of nonempty messages. This includes recovered attributedBody text.
- The Hall of Fame leaderboard shows the top five **readable text** messages by linked Haha reactions. A media-only message can hold the overall reaction record without a readable text preview.
- The 2025→2026 comparison uses each person's **share of messages**, not raw year-over-year counts, since both snapshots have incomplete year coverage.

## Privacy

This is a **local file** and has no analytics, tracking scripts, APIs, login, or upload endpoint. The 20 slides are generated from a small processed JS data file which includes top-message quotes; those quotes can be seen by anyone with a copy of the website. **Only share cards containing text you're comfortable sharing.** The only optional network request is for Google Fonts (Space Grotesk + Inter) while connected to the internet. Offline, your browser will use installed fallback fonts instead. For maximum privacy, keep the HTML and site ZIP on your Mac; do not host them on a public website.

## What's inside

- `index.html`, `style.css`, `app.js`: website layout, interaction, and style.
- `app-data.js`: processed statistics, award winners, and selected group-chat quotes. Contains **some private content**.
- `build_data.py`: reproducible data generation from the enriched CSV or a copied Mac database.
- `make_standalone.py`: constructs the convenient single-file HTML after a refresh.

This is the **first prototype**, meant to be reviewed and revised before a final launch.
