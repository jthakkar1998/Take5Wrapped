#!/usr/bin/env python3
"""Combine the local web assets into one portable HTML file; no web server required."""
from pathlib import Path
import re
root=Path(__file__).resolve().parent
base=(root/'index.html').read_text(encoding='utf-8')
css=(root/'style.css').read_text(encoding='utf-8')
data=(root/'app-data.js').read_text(encoding='utf-8')
script=(root/'app.js').read_text(encoding='utf-8')
# User-supplied quotes are represented within JS data: don't let a chat quote close a script tag.
data=re.sub(r'</(?=script)',r'<\\/',data,flags=re.IGNORECASE)
base=base.replace('<link rel="stylesheet" href="style.css">','<style>\n'+css+'\n</style>')
base=base.replace('<script src="app-data.js"></script>','<script>\n'+data+'\n</script>')
base=base.replace('<script defer src="app.js"></script>','')
base=base.replace('</body>','<script>\n'+script+'\n</script>\n</body>')
out=root.parent/'Take_5_deez_Wrapped.html'
out.write_text(base,encoding='utf-8')
print('Created',out,'('+str(out.stat().st_size)+' bytes)')
